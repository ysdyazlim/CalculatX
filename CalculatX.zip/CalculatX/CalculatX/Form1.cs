﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HesapX
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Load
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome!");
            

        }
        //Çarp
        private void Çarp_Click(object sender, EventArgs e)
        {
            double s1, s2, sonuç;
            s1 = Convert.ToDouble(Sayi1.Text);
            s2 = Convert.ToDouble(Sayi2.Text);
            sonuç = s1 * s2;
            label4.Text = Convert.ToString(sonuç);
        }
        //Topla
        private void Topla_Click(object sender, EventArgs e)
        {
            if(Sayi1 == "") {
                MessageBox.Show("Pleas Enter Number!");
            }
            if (Sayi2 == "")
            {
                MessageBox.Show("Pleas Enter Number!");
            }
            double s1, s2, sonuç;
            s1 = Convert.ToDouble(Sayi1.Text);
            s2 = Convert.ToDouble(Sayi2.Text);
            sonuç = s1 + s2;
            label4.Text = Convert.ToString(sonuç);
        }
        //Böl
        private void Böl_Click(object sender, EventArgs e)
        {
            double s1, s2, sonuç;
            s1 = Convert.ToDouble(Sayi1.Text);
            s2 = Convert.ToDouble(Sayi2.Text);
            sonuç = s1 / s2;
            label4.Text = Convert.ToString(sonuç);
        }
        //Çıkart
        private void Çıkart_Click(object sender, EventArgs e)
        {
            double s1, s2, sonuç;
            s1 = Convert.ToDouble(Sayi1.Text);
            s2 = Convert.ToDouble(Sayi2.Text);
            sonuç = s1 - s2;
            label4.Text = Convert.ToString(sonuç);
        }
        //Çıkış
        private void Çıkış_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Good Bye!");
            this.Close();
        }
 

    }
}
